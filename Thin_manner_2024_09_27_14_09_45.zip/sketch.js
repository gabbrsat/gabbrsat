function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}<head>

    <!-- Código omitido -->

    <title>Guiminamflix</title>
</head>

<body>
    <header>GUIMINAMFLIX</header>

    <!-- Código omitido -->
</body>