function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}/* código escondido */

.categoria-videos img {}
    opacity 0.5; {}
}/* código escondido */

p {
    font-size: 20px;
}

.categoria-videos {
    
}

/* código escondido */

.categoria-videos img {
    opacity 0.5;
    height: 200px
}/* código escondido */

.categoria-videos img {
    opacity 0.5;
    height: 200px
}

.categoria-videos img:hover {
    opacity 1.0;
}/* código escondido */

.categoria-videos img:hover {
    opacity 1.0;
}

.categoria h2 {
    color: rgb(42, 122, 228);
}element.style {
    margin-bottom: 50px;
}

/* código escondido */element.style {
    margin-bottom: 50px;
    margin-top: 50px;
}

/* código escondido */element.style {
    margin-bottom: 100px;
    margin-top: 50px;
}

/* código escondido */element.style {
    margin-bottom: 50px;
}

/* código escondido *//* código escondido */

.categoria {
    padding-left: 20px;
    padding-right: 20px;
    margin-top: 50px;
}

/* código escondido */body {
    color: white;
    background: black;
    margin: 0px;
    font-family: "Chakra Petch", sans-serif;
    margin-bottom: 100px;
}

/* código escondido */